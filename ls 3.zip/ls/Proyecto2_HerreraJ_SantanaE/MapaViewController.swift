//
//  MapaViewController.swift
//  Proyecto2_HerreraJ_SantanaE
//
//  Created by 2020-1 on 11/7/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapaViewController: UIViewController, MKMapViewDelegate {
    
    var lugar: sites!
    var tipo: MKDirectionsTransportType = []
     var bar: String = "Me parece que no seleccionaste un tipo de transporte\nNo te preocupes, lo hicimos por ti (regresa si quieres personalizar tu ruta.)"

    @IBOutlet weak var mapa: MKMapView!
    
    @IBOutlet weak var frase: UILabel!
    @IBOutlet weak var distancia: UILabel!
   

    
    override func viewDidLoad() {
        super.viewDidLoad()
        if (tipo == .automobile){
            bar = "Hoy es un buen día para conducir, llega a tu destino con buena música."
            frase.text = bar
        }
        if (tipo == .transit){
            bar = "Recuerda que con el calor, sube el mal humor. Sé cordial con alguien a tu alrededor."
            frase.text = bar
        }
        if (tipo == .walking){
            bar = "Las mejores ideas salen cuando caminas, mantente hidratado y filosofando"
            frase.text = bar
            
        }
        
        var destinos = lugar.coordenadas
        frase.text = bar
        mapa.delegate = self
        
      
        
        //El inicio siempre será desde el anexo de ingeniería
        let inicioLocation = CLLocationCoordinate2D(latitude: 19.3272501, longitude: -99.1825469)
        destinos = CLLocationCoordinate2D(latitude: lugar.coordenadas.latitude, longitude: lugar.coordenadas.longitude)
        let inicioPin = Direccion(title: "Ingeniería", subtitle: "Anexo", coordinate: inicioLocation)
        let destinoPin = Direccion(title: "\(lugar.nombre)", subtitle: "Precisión Buena", coordinate: destinos)
        mapa.addAnnotations([inicioPin,destinoPin])
        
        
        // Creación de placemarks
        let inicioPlaceMark = MKPlacemark(coordinate: inicioLocation)
        let destinoPlaceMark = MKPlacemark(coordinate: destinos)
        
        let direccionRequest = MKDirections.Request()
        
        direccionRequest.source = MKMapItem(placemark: inicioPlaceMark)
        direccionRequest.destination = MKMapItem(placemark: destinoPlaceMark)
        direccionRequest.transportType = tipo
        let directions = MKDirections(request: direccionRequest)
        
        directions.calculate{
            (response, error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
            guard let directionResponse = response else {
                return
            }
            let ruta = directionResponse.routes.first
            self.mapa.addOverlay(ruta!.polyline)
            let rect = ruta?.polyline.boundingMapRect
            self.mapa.setRegion(MKCoordinateRegion(rect!), animated: true)
        }
        //Distancia
        let inicio = CLLocation(latitude: 19.3272501, longitude: -99.1825469)
        let destino = CLLocation(latitude: lugar.coordenadas.latitude, longitude: lugar.coordenadas.longitude)
        let recorrido = inicio.distance(from: destino)
        print(recorrido)
        let distanciaFormateada = String(format: "Distancia %0.2f metros",recorrido)
        print("\(distanciaFormateada)")
        distancia.text = "\(distanciaFormateada)"
        
    }
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let linea = MKPolylineRenderer(overlay: overlay)
        linea.strokeColor = .blue
        linea.lineWidth = 3.0
        return linea
    }
    
   
    @IBAction func cerrar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    
    

}
