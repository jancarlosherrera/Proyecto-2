//
//  Sitios.swift
//  Proyecto2_HerreraJ_SantanaE
//
//  Created by 2020-1 on 11/8/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit
import MapKit

struct sites{
    var nombre: String
    var Coordenadas: CLLocationCoordinate2D
    var pin: String
}
