//
//  IntrodViewController.swift
//  Proyecto2_HerreraJ_SantanaE
//
//  Created by 2020-1 on 11/12/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit
import Lottie

class IntrodViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let animationView = AnimationView(name: "lottie3")
        animationView.frame = CGRect(x: 0, y: 0, width: 400, height: 400)
        animationView.center = self.view.center
        animationView.contentMode = .scaleAspectFill
        view.backgroundColor = .black
        
        view.addSubview(animationView)
        animationView.loopMode = .loop
        
        animationView.play()
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
