//
//  Lugar.swift
//  Proyecto2_HerreraJ_SantanaE
//
//  Created by 2020-1 on 11/5/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit
import MapKit

struct Lugares: Codable{
    var nombre: String
    var latit: Double
    var longit: Double
    var pin: String
}

/*func obtener(nombre: String){
    var setes: [sites] = []
let path = Bundle.main.path(forResource: "Informacion", ofType: "json")
let jsonData = NSData(contentsOfFile: path!)
let Lugars = try! JSONDecoder().decode([Lugares].self, from: jsonData! as Data)
    for yea in Lugars{
        
        let nombre = yea.Nombre
        let coordenadas = CLLocationCoordinate2D(latitude: yea.latit, longitude: yea.longit)
        let pin = yea.pin
        
        print(nombre,",",coordenadas,",",pin,",")
        
            
            
        }


}


 */
