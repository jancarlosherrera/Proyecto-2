//
//  introTableViewCell.swift
//  Proyecto2_HerreraJ_SantanaE
//
//  Created by 2020-1 on 11/5/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit

class introTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nombre: UILabel!
    @IBOutlet weak var imagen: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
