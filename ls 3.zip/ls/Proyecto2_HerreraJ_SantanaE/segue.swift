//
//  segue.swift
//  Proyecto2_HerreraJ_SantanaE
//
//  Created by 2020-1 on 11/12/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit

class segue: UIStoryboardSegue {
    
    
   /* override func perform(_ aSelector: mapita, with anArgument: Any?, afterDelay delay: 6) {
        return
    } */

}
