//
//  ViewController.swift
//  Proyecto2_HerreraJ_SantanaE
//
//  Created by 2020-1 on 11/5/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Lottie

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    var Sitios: [sites] = [sites]()
    
    var tipo: MKDirectionsTransportType = []
    @IBOutlet weak var tabla: UITableView!
    
    func obtener(){
        let path = Bundle.main.path(forResource: "Informacion", ofType: "json")
        let jsonData = NSData(contentsOfFile: path!)
        let Lugars = try! JSONDecoder().decode([Lugares].self, from: jsonData! as Data)
        for yea in Lugars{
            
            let nombre = yea.nombre
            let coordenadas = CLLocationCoordinate2D(latitude: yea.latit, longitude: yea.longit)
            let pin = yea.pin
            
            self.Sitios.append(sites(nombre: "\(nombre)", coordenadas: coordenadas, pin: "\(pin)"))
            
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabla.delegate = self
        tabla.dataSource = self
        obtener()
       
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Sitios.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
         let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! introTableViewCell
        
        
        cell.nombre?.text = Sitios[indexPath.row].nombre
        cell.imagen?.image =  UIImage(named: Sitios[indexPath.row].pin)
        
        
        return cell
        
    }
    @IBAction func coche(_ sender: Any) {
        tipo = .automobile
        
        
    }
    
    @IBAction func bicicleta(_ sender: Any) {
        tipo = .walking
    }
    
    @IBAction func caminando(_ sender: Any) {
        tipo = .transit
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let Mapa = segue.destination as! MapaViewController
        let myIndexPath = tabla.indexPathForSelectedRow
        Mapa.lugar = Sitios[(myIndexPath?.row)!]
        Mapa.tipo = tipo
        
    }

}

